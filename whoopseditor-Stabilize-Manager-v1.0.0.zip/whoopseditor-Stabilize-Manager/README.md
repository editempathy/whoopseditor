# ⚡ Stabilize Manager for DaVinci Resolve

> Native batch stabilization manager and instant 1-click silent stabilizer with intelligent re-trim auditing.

Part of the **whoopseditor** suite for DaVinci Resolve.

[![Star on GitHub](https://img.shields.io/github/stars/editempathy/whoopseditor?style=social)](https://github.com/editempathy/whoopseditor)
[![Instagram @whoopseditor](https://img.shields.io/badge/Instagram-@whoopseditor-E4405F?style=flat&logo=instagram&logoColor=white)](https://instagram.com/whoopseditor)
[![Instagram @i.vkpraveenkumar](https://img.shields.io/badge/Personal-@i.vkpraveenkumar-833AB4?style=flat&logo=instagram&logoColor=white)](https://instagram.com/i.vkpraveenkumar)

<p align="center">
  <img src="../assets/preview_colors_tab.png" alt="Stabilize Manager - Clip Colors Tab" width="600" />
</p>

---

> ⭐ **If this tool saves you time, please give this repository a star!** It helps more video editors discover free workflow tools.

---

## 🚀 Quick Installation

### macOS:
Double-click `Install_Mac.command`. (Done!)

### Windows:
Right-click `Install_Windows.bat` and click **Run**. (Done!)

### Manual Installation:
Copy `Stabilize_Manager.py` and `Stabilize_Clip.py` to:
* **macOS**: `~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Edit/`
* **Windows**: `%APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts\Edit\`

---

## 🛠 Features

| Tab | Preview | Description |
| :--- | :---: | :--- |
| **Current Clip** | <img src="../assets/preview_current_tab.png" width="300"/> | Fast stabilization of whatever clip is currently under your playhead. |
| **Video Tracks** | <img src="../assets/preview_tracks_tab.png" width="300"/> | Select any video tracks (V1, V2, V3...) to batch stabilize sequentially. |
| **Clip Colors** | <img src="../assets/preview_colors_tab.png" width="300"/> | Filter and batch-stabilize clips by color tags (or uncolored clips). Supports Current Timeline & Entire Project. |
| **Check Clips** | <img src="../assets/preview_audit_tab.png" width="300"/> | Intelligent edit-point auditor: flags re-trimmed or lengthened clips and re-stabilizes in 1 click. |

### ⚡ Silent Hotkey Stabilizer (`Stabilize_Clip`)
Assign a custom shortcut in DaVinci Resolve (**Keyboard Customization** → **Scripts** → `Stabilize_Clip`) for background 1-key stabilization with zero UI interruption!

---

## 🎁 100% Free for the Community
All tools in **whoopseditor** are **100% free** for both personal and commercial projects. No paywalls, no subscriptions.

## 💡 Got a DaVinci Resolve Bottleneck?
Facing a repetitive, annoying editing problem or have an idea for a tool that would save hours of work?  
**Drop me a message! If it's a problem other editors face too, I will build the tool and release it for FREE.**

* 💬 **Instagram DM**: [@whoopseditor](https://instagram.com/whoopseditor) or [@i.vkpraveenkumar](https://instagram.com/i.vkpraveenkumar)
* 📧 **Email**: [editempathy@gmail.com](mailto:editempathy@gmail.com)
* 💡 **Feature Requests**: Open an [Issue](https://github.com/editempathy/whoopseditor/issues) on GitHub
